@echo off
:: ============================================================
::  GamePad Pro  v6.0  —  GOD MODE ULTIMATE LAUNCHER
::  Merged from v4.0 + v5.0
::  Works via: WiFi | Ethernet | USB | Bluetooth | Internet
::  Features: Auto Node install | Auto packages | Auto-restart
::             RobotJS | localtunnel | QR code | Browser open
:: ============================================================
chcp 65001 >nul 2>&1
title 🎮 GamePad Pro v6.0 — GOD MODE ULTIMATE
color 0A
cls

echo.
echo  ╔═══════════════════════════════════════════════════════╗
echo  ║   🎮  GamePad Pro  v6.0  —  GOD MODE ULTIMATE        ║
echo  ║   Phone ^→ PC  ^|  WiFi / USB / Bluetooth / Internet   ║
echo  ╚═══════════════════════════════════════════════════════╝
echo.

:: ── STEP 1: Check / install Node.js ─────────────────────────────
echo  [1/5] Checking Node.js...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [WARN] Node.js not found. Trying to install via winget...
    echo.
    winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
    if %errorlevel% neq 0 (
        echo  [ERROR] Auto-install failed.
        echo  Please manually install from: https://nodejs.org
        start https://nodejs.org
        pause
        exit /b 1
    )
    echo  [OK] Node.js installed! Relaunching...
    start "" "%~f0"
    exit /b 0
)
for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo  [OK] Node.js %NODE_VER%

:: ── STEP 2: Install packages ─────────────────────────────────────
echo  [2/5] Checking packages...
if not exist "node_modules\express" (
    echo  [INFO] First run — installing packages. Please wait...
    echo.
    npm install --prefer-offline >nul 2>&1
    if %errorlevel% neq 0 (
        echo  [INFO] Trying online install...
        call npm install
    )
    if %errorlevel% neq 0 (
        echo  [ERROR] npm install failed. Check internet connection.
        pause
        exit /b 1
    )
    echo  [OK] Packages installed!
) else (
    echo  [OK] node_modules found.
)

:: ── STEP 3: Install ws + qrcode (v6 core deps) ───────────────────
echo  [3/5] Checking ws + qrcode...
if not exist "node_modules\ws" (
    echo  [INFO] Installing ws and qrcode...
    call npm install ws qrcode qrcode-terminal localtunnel >nul 2>&1
    echo  [OK] Core packages ready!
) else (
    echo  [OK] ws + qrcode found.
)

:: ── STEP 4: Install robotjs (optional, for OS-level key control) ──
echo  [4/5] Checking robotjs...
node -e "require('@jitsi/robotjs')" >nul 2>&1
if %errorlevel% neq 0 (
    node -e "require('robotjs')" >nul 2>&1
    if %errorlevel% neq 0 (
        echo  [INFO] Installing robotjs (keyboard + mouse control)...
        call npm install @jitsi/robotjs >nul 2>&1
        if %errorlevel% neq 0 (
            call npm install robotjs >nul 2>&1
            if %errorlevel% neq 0 (
                echo  [WARN] robotjs install failed.
                echo  [WARN] Try: right-click start.bat → Run as Administrator
                echo  [WARN] Server will start in DEMO mode (browser games still work).
            ) else (
                echo  [OK] robotjs installed!
            )
        ) else (
            echo  [OK] @jitsi/robotjs installed!
        )
    ) else (
        echo  [OK] robotjs already present.
    )
) else (
    echo  [OK] @jitsi/robotjs already present.
)

:: ── STEP 5: Detect IP + show URLs ────────────────────────────────
echo  [5/5] Detecting network IP...
set LOCAL_IP=localhost
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4" ^| findstr /v "127.0.0.1" ^| findstr /v "169.254"') do (
    for /f "tokens=1" %%b in ("%%a") do (
        set LOCAL_IP=%%b
        goto :got_ip
    )
)
:got_ip
echo  [OK] IP: %LOCAL_IP%
echo.

echo  ╔═══════════════════════════════════════════════════════╗
echo  ║  HOW TO USE:                                         ║
echo  ╠═══════════════════════════════════════════════════════╣
echo  ║  PC PAGE   →  http://localhost:3000/pc.html          ║
echo  ║  MOBILE    →  http://%LOCAL_IP%:3000/mobile.html     ║
echo  ║  LANDING   →  http://localhost:3000/landing.html     ║
echo  ╠═══════════════════════════════════════════════════════╣
echo  ║  CONNECTION METHODS:                                  ║
echo  ║  📶 WiFi    — same router, scan QR in browser        ║
echo  ║  🔌 Ethernet— PC wired, phone on WiFi                ║
echo  ║  🔗 USB     — Settings → Hotspot → USB Tethering     ║
echo  ║  🔵 BT PAN  — Bluetooth Personal Area Network        ║
echo  ║  🌐 Internet— public URL shown in console (any net)  ║
echo  ╚═══════════════════════════════════════════════════════╝
echo.
echo  FIREWALL TIP: Click "Allow" if Windows asks about port 3000
echo  ADMIN TIP:    If key inputs don't reach games, Run as Administrator
echo.

:: ── Open PC page in browser ───────────────────────────────────────
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000/pc.html"

:: ── GOD MODE LOOP: auto-restart on crash ─────────────────────────
:GOD_MODE_LOOP
echo  ╔═══════════════════════════════════════════════════════╗
echo  ║  SERVER RUNNING  —  Press Ctrl+C to stop             ║
echo  ╚═══════════════════════════════════════════════════════╝
echo.
node server.js
if %errorlevel% neq 0 (
    echo.
    echo  ⚠  Server crashed (code %errorlevel%). Auto-restarting in 3s...
    echo  Press Ctrl+C TWICE to fully stop.
    echo.
    timeout /t 3 >nul
    goto GOD_MODE_LOOP
)

echo.
echo  Server stopped normally. Press any key to exit.
pause
