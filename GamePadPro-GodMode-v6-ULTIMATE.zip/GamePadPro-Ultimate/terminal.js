#!/usr/bin/env node
'use strict';
// ════════════════════════════════════════════════════════════════════
//  GamePad Pro  —  GOD MODE TERMINAL  v6.0
//  All-in-one TUI:  Dashboard | Controller | Logs | Setup Wizard
//  Usage:  node terminal.js
//          PORT=4000 node terminal.js
// ════════════════════════════════════════════════════════════════════

const http    = require('http');
const os      = require('os');
const readline= require('readline');
const { spawn } = require('child_process');

const HOST = process.env.HOST || 'localhost';
const PORT = process.env.PORT || 3000;
const BASE = `http://${HOST}:${PORT}`;

// ── ANSI helpers ─────────────────────────────────────────────────────
const A = {
  reset:'\x1b[0m', bold:'\x1b[1m', dim:'\x1b[2m',
  black:'\x1b[30m', red:'\x1b[31m', green:'\x1b[32m',
  yellow:'\x1b[33m', blue:'\x1b[34m', magenta:'\x1b[35m',
  cyan:'\x1b[36m', white:'\x1b[37m',
  bred:'\x1b[91m', bgreen:'\x1b[92m', byellow:'\x1b[93m',
  bblue:'\x1b[94m', bmagenta:'\x1b[95m', bcyan:'\x1b[96m', bwhite:'\x1b[97m',
  bgblack:'\x1b[40m', bggreen:'\x1b[42m', bgblue:'\x1b[44m', bgred:'\x1b[41m',
  clear:'\x1b[2J\x1b[H', hide:'\x1b[?25l', show:'\x1b[?25h',
  clearLine:'\x1b[2K',
};

const w   = (s) => process.stdout.write(s);
const c   = (col, s) => `${A[col] || ''}${s}${A.reset}`;
const b   = (s) => `${A.bold}${s}${A.reset}`;
const dim = (s) => `${A.dim}${s}${A.reset}`;

// ── State ─────────────────────────────────────────────────────────────
const S = {
  tab: 'dashboard',   // dashboard | controller | logs | setup
  status: null,
  logs: [],
  ws: null,
  wsConnected: false,
  running: true,
  width:  process.stdout.columns || 80,
  height: process.stdout.rows    || 24,
};

// ── HTTP helpers ──────────────────────────────────────────────────────
function httpGet(path) {
  return new Promise(resolve => {
    http.get(`${BASE}${path}`, res => {
      let d = '';
      res.on('data', ch => d += ch);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve(null); } });
    }).on('error', () => resolve(null));
  });
}

function httpPost(path, body) {
  return new Promise(resolve => {
    const data = JSON.stringify(body);
    const req  = http.request({
      hostname: HOST, port: PORT, path, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
    }, res => {
      let d = '';
      res.on('data', ch => d += ch);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { resolve(null); } });
    });
    req.on('error', () => resolve(null));
    req.write(data);
    req.end();
  });
}

// ── WebSocket (logs) ──────────────────────────────────────────────────
function connectWS() {
  if (S.ws) return;
  try {
    const WebSocket = require('ws');
    const ws = new WebSocket(`ws://${HOST}:${PORT}`);
    S.ws = ws;
    ws.on('open', () => {
      S.wsConnected = true;
      ws.send(JSON.stringify({ type: 'register', role: 'pc', room: 'terminal' }));
      log('sys', 'WebSocket connected to server');
    });
    ws.on('message', raw => {
      try { log('recv', JSON.stringify(JSON.parse(raw.toString()))); }
      catch { log('recv', raw.toString()); }
    });
    ws.on('close', () => {
      S.wsConnected = false; S.ws = null;
      log('sys', 'WS disconnected — retry in 3s...');
      setTimeout(connectWS, 3000);
    });
    ws.on('error', () => { S.ws = null; S.wsConnected = false; });
  } catch {
    log('sys', 'ws module missing — run: npm install ws');
  }
}

function log(type, msg) {
  const ts = new Date().toTimeString().slice(0, 8);
  S.logs.push({ ts, type, msg: String(msg) });
  if (S.logs.length > 300) S.logs.shift();
}

// ── Layout helpers ────────────────────────────────────────────────────
function stripAnsi(s) { return s.replace(/\x1b\[[0-9;]*m/g, ''); }

function pad(s, n) {
  const l = stripAnsi(s).length;
  return s + (l < n ? ' '.repeat(n - l) : '');
}

function center(s, n) {
  const l = stripAnsi(s).length;
  const p = Math.max(0, n - l);
  return ' '.repeat(Math.floor(p / 2)) + s + ' '.repeat(p - Math.floor(p / 2));
}

function box(title, lines, W, col = 'cyan') {
  const inner = W - 2;
  const HR    = '═'.repeat(inner);
  const clr   = A[col] || A.cyan;
  const rst   = A.reset;
  const border= (l, r, m) => `${clr}${l}${m}${r}${rst}`;
  const row   = (s) => `${clr}║${rst}${pad(s, inner)}${clr}║${rst}`;

  return [
    border('╔', '╗', HR),
    `${clr}║${rst}${center(c(col, b(' ' + title + ' ')), inner)}${clr}║${rst}`,
    border('╠', '╣', HR),
    ...lines.map(row),
    border('╚', '╝', HR),
  ].join('\n');
}

// ── HEADER ────────────────────────────────────────────────────────────
function drawHeader() {
  S.width  = process.stdout.columns || 80;
  S.height = process.stdout.rows    || 24;
  const W  = S.width;

  const TABS = [
    ['1', 'Dashboard',  'dashboard'],
    ['2', 'Controller', 'controller'],
    ['3', 'Logs',       'logs'],
    ['4', 'Setup',      'setup'],
  ];

  w(A.clear + A.hide);

  const logo = c('bgreen', b('🎮 GamePad Pro  GOD MODE TERMINAL  v6.0'));
  w(`${A.bgreen}╔${'═'.repeat(W-2)}╗${A.reset}\n`);
  w(`${A.bgreen}║${A.reset}${center(logo, W-2)}${A.bgreen}║${A.reset}\n`);
  w(`${A.bgreen}╠${'═'.repeat(W-2)}╣${A.reset}\n`);

  let bar = '  ';
  TABS.forEach(([num, name, id]) => {
    if (S.tab === id)
      bar += `${A.bggreen}${A.black}${b(` [${num}] ${name} `)}${A.reset}  `;
    else
      bar += `${A.dim}[${num}] ${name}${A.reset}  `;
  });
  bar += `${A.dim}[Q] Quit${A.reset}`;
  w(`${A.bgreen}║${A.reset} ${bar}\n`);
  w(`${A.bgreen}╚${'═'.repeat(W-2)}╝${A.reset}\n\n`);
}

// ── DASHBOARD ─────────────────────────────────────────────────────────
function drawDashboard() {
  const s = S.status;
  const W = S.width;
  let lines;

  if (!s) {
    lines = [
      '',
      `  ${c('yellow', '⏳ Waiting for server...')}`,
      '',
      `  ${dim('Make sure server is running:')}`,
      `  ${c('bwhite', 'node server.js')}`,
      '',
      `  ${dim('Target:')}  ${c('bwhite', BASE)}`,
      '',
      `  ${dim('Press [4] → Setup to start the server from here.')}`,
      '',
    ];
  } else {
    const rb = s.robotjs
      ? c('bgreen', '✅ Active (real keyboard + mouse)')
      : c('yellow', '⚠  Demo mode (no real OS input)');

    const held = Object.entries(s.keys || {})
      .filter(([, v]) => v).map(([k]) => c('bgreen', `[${k}]`)).join(' ') || dim('none');

    lines = [
      '',
      `  ${dim('Version')}      ${b(c('bcyan', s.version || '6.0-ultimate'))}`,
      `  ${dim('RobotJS')}      ${rb}`,
      `  ${dim('Screen')}       ${c('bwhite', s.screen)}`,
      `  ${dim('Worker PID')}   ${c('bwhite', String(s.worker))}`,
      `  ${dim('Uptime')}       ${c('bwhite', s.uptime)}`,
      `  ${dim('Rooms')}        ${c('bwhite', String(s.rooms))}`,
      `  ${dim('Sensitivity')}  ${c('bwhite', String(s.sensitivity))}`,
      `  ${dim('Keys held')}    ${held}`,
      '',
      `  ${c('byellow', '━━ Network Interfaces ━━')}`,
      ...getIPs().map(({ type, ip }) =>
        `  ${type}  ${c('bwhite', `http://${ip}:${PORT}/mobile.html`)}`
      ),
      ...(getIPs().length === 0 ? [`  ${dim('No external interfaces detected')}`] : []),
      '',
      `  ${dim('PC page')}   ${c('bwhite', `http://localhost:${PORT}/pc.html`)}`,
      `  ${dim('Status')}    ${c('bwhite', `http://localhost:${PORT}/status`)}`,
      '',
    ];
  }

  w(box('📊  SERVER STATUS', lines, W, 'cyan'));
  w(`\n  ${dim('Auto-refreshes every 2s')}\n`);
}

// ── CONTROLLER ────────────────────────────────────────────────────────
function drawController() {
  const W  = S.width;
  const ws = S.wsConnected ? c('bgreen', '🟢 Connected') : c('bred', '🔴 Not connected');

  const lines = [
    '',
    `  ${dim('Sends keystrokes + mouse via REST API')}   WS: ${ws}`,
    '',
    `  ${c('byellow', '━━ Movement ━━')}        ${c('byellow', '━━ Actions ━━')}`,
    `  ${c('bwhite','W A S D')}  Move            ${c('bwhite','SPACE')}  Jump / A button`,
    `  ${c('bwhite','SHIFT')}    Hold to sprint  ${c('bwhite','R')}      Reload / RB`,
    `                          ${c('bwhite','F')}      Interact / X`,
    `  ${c('byellow', '━━ Mouse (Arrow Keys) ━━')}  ${c('bwhite','E')}      Use / Y`,
    `  ${c('bwhite','↑ ↓ ← →')}  Move mouse 50px ${c('bwhite','G')}      Grenade`,
    `                          ${c('bwhite','M')}      Map`,
    `  ${c('byellow', '━━ System ━━')}            ${c('bwhite','TAB')}    Inventory`,
    `  ${c('bwhite','ENTER')}  Start button      ${c('bwhite','ESC')}    B button`,
    `  ${c('bwhite','Z')}      LS click          ${c('bwhite','X')}      RS click`,
    `  ${c('bwhite','C')}      Crouch            ${c('bwhite','V')}      Melee`,
    '',
    `  ${c('yellow', '⚡ Keys are tapped (press + release).  Mouse moves 50px per arrow press.')}`,
    `  ${dim('Tab Q exits to quit. Use Ctrl+C to force stop.')}`,
    '',
  ];

  w(box('🕹️   CONTROLLER — Type keys in this terminal', lines, W, 'magenta'));
}

// ── LOGS ──────────────────────────────────────────────────────────────
function drawLogs() {
  const W       = S.width;
  const maxRows = Math.max(5, S.height - 16);
  const recent  = S.logs.slice(-maxRows);

  const lines = recent.length === 0
    ? ['', `  ${dim('No events yet — waiting for connections...')}`, '']
    : recent.map(({ ts, type, msg }) => {
        const maxMsg = W - 22;
        const short  = msg.length > maxMsg ? msg.slice(0, maxMsg - 3) + '...' : msg;
        const typeC  =
          type === 'sys'  ? c('yellow',  'SYS ') :
          type === 'send' ? c('bgreen',  'SEND') :
          type === 'recv' ? c('bblue',   'RECV') :
                            dim(type.padEnd(4));
        return `  ${dim(ts)}  ${typeC}  ${short}`;
      });

  w(box('📋  EVENT LOGS', lines, W, 'blue'));
  w(`\n  ${dim(`Showing last ${recent.length} of ${S.logs.length} events  |  [C] Clear`)}\n`);
}

// ── SETUP ─────────────────────────────────────────────────────────────
function drawSetup() {
  const W = S.width;

  const nodeVer  = process.version;
  const hasExp   = hasModule('express');
  const hasWs    = hasModule('ws');
  const hasQr    = hasModule('qrcode');
  const hasQrT   = hasModule('qrcode-terminal');
  const hasRobot = hasModule('@jitsi/robotjs') || hasModule('robotjs');
  const tick = (ok) => ok ? c('bgreen', '✅') : c('bred', '❌');
  const opt  = (ok) => ok ? c('bgreen', '✅') : c('yellow', '⚠ ');

  const lines = [
    '',
    `  ${c('byellow', '━━ Environment ━━')}`,
    `  ${tick(true)}   Node.js          ${c('bgreen', nodeVer)}`,
    `  ${tick(hasExp)}   express          ${hasExp  ? c('bgreen','OK') : c('bred','Missing → press [I]')}`,
    `  ${tick(hasWs)}   ws               ${hasWs   ? c('bgreen','OK') : c('bred','Missing → press [I]')}`,
    `  ${tick(hasQr)}   qrcode           ${hasQr   ? c('bgreen','OK') : c('bred','Missing → press [I]')}`,
    `  ${tick(hasQrT)}   qrcode-terminal  ${hasQrT  ? c('bgreen','OK') : c('bred','Missing → press [I]')}`,
    `  ${opt(hasRobot)}   @jitsi/robotjs   ${hasRobot? c('bgreen','OK') : c('yellow','Optional → press [R]')}`,
    '',
    `  ${c('byellow', '━━ Actions ━━')}`,
    `  ${c('bwhite', '[I]')}  Install all deps    ${dim('npm install')}`,
    `  ${c('bwhite', '[R]')}  Install robotjs     ${dim('npm install @jitsi/robotjs')}`,
    `  ${c('bwhite', '[S]')}  Start server        ${dim('node server.js  (background)')}`,
    `  ${c('bwhite', '[P]')}  Print QR code       ${dim('qrcode-terminal → Logs tab')}`,
    `  ${c('bwhite', '[C]')}  Clear logs`,
    '',
    `  ${c('byellow', '━━ Network ━━')}`,
    ...getIPs().map(({ type, ip }) =>
      `  ${type}  ${c('bwhite', `http://${ip}:${PORT}/mobile.html`)}`
    ),
    ...(getIPs().length === 0 ? [`  ${dim('No external adapters detected')}`] : []),
    '',
    `  ${c('byellow', '━━ Server ━━')}`,
    `  ${S.status ? c('bgreen', '🟢 Running') : c('bred', '🔴 Not reachable')}  ${dim(BASE)}`,
    '',
  ];

  w(box('⚙️   SETUP WIZARD', lines, W, 'yellow'));
}

// ── RENDER ────────────────────────────────────────────────────────────
function render() {
  if (!S.running) return;
  drawHeader();
  switch (S.tab) {
    case 'dashboard':  drawDashboard();  break;
    case 'controller': drawController(); break;
    case 'logs':       drawLogs();       break;
    case 'setup':      drawSetup();      break;
  }
  w(`\n  ${dim('[1] Dashboard  [2] Controller  [3] Logs  [4] Setup  [Q] Quit  [Ctrl+C] Force exit')}\n`);
}

// ── SETUP ACTIONS ─────────────────────────────────────────────────────
function runAction(action) {
  S.tab = 'logs';
  switch (action) {
    case 'install': {
      log('sys', '▶ Running: npm install ...');
      const ch = spawn('npm', ['install'], { cwd: __dirname, shell: true });
      ch.stdout.on('data', d => log('sys', d.toString().trim()));
      ch.stderr.on('data', d => log('sys', d.toString().trim()));
      ch.on('close', code => log('sys', `✅ npm install done (exit ${code})`));
      break;
    }
    case 'robotjs': {
      log('sys', '▶ Running: npm install @jitsi/robotjs ...');
      const ch = spawn('npm', ['install', '@jitsi/robotjs'], { cwd: __dirname, shell: true });
      ch.stdout.on('data', d => log('sys', d.toString().trim()));
      ch.stderr.on('data', d => log('sys', d.toString().trim()));
      ch.on('close', code => log('sys', `✅ @jitsi/robotjs done (exit ${code})`));
      break;
    }
    case 'start': {
      log('sys', '▶ Starting server.js in background...');
      const ch = spawn('node', ['server.js'], {
        cwd: __dirname, detached: true, stdio: 'ignore',
      });
      ch.unref();
      log('sys', `✅ Server started  PID=${ch.pid}`);
      setTimeout(() => { S.tab = 'dashboard'; render(); }, 1500);
      break;
    }
    case 'qr': {
      try {
        const qt  = require('qrcode-terminal');
        const ip  = getIPs()[0]?.ip || 'localhost';
        const url = `http://${ip}:${PORT}/mobile.html`;
        log('sys', `▶ QR → ${url}`);
        qt.generate(url, { small: true }, (qr) => {
          qr.split('\n').forEach(l => log('sys', l));
          log('sys', `URL: ${url}`);
          render();
        });
      } catch {
        log('sys', '❌ qrcode-terminal not installed — press [I] to install all deps');
      }
      break;
    }
    case 'clearLogs':
      S.logs = [];
      log('sys', 'Logs cleared.');
      break;
  }
}

// ── KEYBOARD ──────────────────────────────────────────────────────────
function setupInput() {
  readline.emitKeypressEvents(process.stdin);
  if (process.stdin.isTTY) process.stdin.setRawMode(true);

  process.stdin.on('keypress', async (str, key) => {
    if (!key) return;

    // Force exit
    if (key.ctrl && key.name === 'c') { cleanup(); return; }

    // Global tab switch
    if (key.name === '1') { S.tab = 'dashboard';  render(); return; }
    if (key.name === '2') { S.tab = 'controller'; render(); return; }
    if (key.name === '3') { S.tab = 'logs';       render(); return; }
    if (key.name === '4') { S.tab = 'setup';      render(); return; }

    // Q to quit (except controller tab where Q = Q key)
    if (key.name === 'q' && S.tab !== 'controller') { cleanup(); return; }

    // ── Controller tab ─────────────────────────────────────────────
    if (S.tab === 'controller') {
      // Arrow → mouse
      const mouseMap = {
        up:    { dx: 0,   dy: -50 },
        down:  { dx: 0,   dy:  50 },
        left:  { dx: -50, dy:   0 },
        right: { dx:  50, dy:   0 },
      };
      if (mouseMap[key.name]) {
        const m = mouseMap[key.name];
        const r = await httpPost('/api/mouse', m);
        log('send', `mouse ${key.name} dx=${m.dx} dy=${m.dy} → ${r ? 'ok' : 'server unreachable'}`);
        render(); return;
      }

      // Keys → tap
      const keyMap = {
        w:'w', a:'a', s:'s', d:'d', space:'space',
        r:'r', f:'f', e:'e', g:'g', m:'m',
        tab:'tab', escape:'escape', return:'return',
        z:'z', x:'x', c:'c', v:'v', shift:'shift',
        q:'q',
      };
      const k = keyMap[key.name];
      if (k) {
        const r1 = await httpPost('/api/key', { key: k, state: 'down' });
        await new Promise(res => setTimeout(res, 80));
        const r2 = await httpPost('/api/key', { key: k, state: 'up' });
        const ok  = r1?.ok || r2?.ok;
        log('send', `key tap [${k}] → ${ok ? 'ok' : 'server unreachable / demo mode'}`);
        render();
      }
      return;
    }

    // ── Logs tab ───────────────────────────────────────────────────
    if (S.tab === 'logs') {
      if (key.name === 'c') { runAction('clearLogs'); render(); return; }
    }

    // ── Setup tab ──────────────────────────────────────────────────
    if (S.tab === 'setup') {
      if (key.name === 'i') { runAction('install');   render(); return; }
      if (key.name === 'r') { runAction('robotjs');   render(); return; }
      if (key.name === 's') { runAction('start');     render(); return; }
      if (key.name === 'p') { runAction('qr');        render(); return; }
      if (key.name === 'c') { runAction('clearLogs'); render(); return; }
    }
  });
}

// ── UTILS ─────────────────────────────────────────────────────────────
function hasModule(name) {
  try { require.resolve(name); return true; } catch { return false; }
}

function getIPs() {
  const nets = os.networkInterfaces();
  const ips  = [];
  for (const name of Object.keys(nets)) {
    for (const a of nets[name]) {
      if (a.family !== 'IPv4' || a.internal) continue;
      const n = name.toLowerCase();
      if (n.includes('vmware') || n.includes('virtualbox') || n.includes('vethernet')) continue;
      let type = '📶 WiFi   ';
      if (n.includes('eth') || n.includes('ethernet') || n.includes('lan'))    type = '🔌 Ethernet';
      else if (n.includes('usb') || n.includes('tether') || n.includes('rndis')) type = '🔗 USB    ';
      else if (n.includes('bt')  || n.includes('bluetooth') || n.includes('pan')) type = '🔵 BT PAN ';
      ips.push({ type, name, ip: a.address });
    }
  }
  return ips;
}

// ── CLEANUP ───────────────────────────────────────────────────────────
function cleanup() {
  S.running = false;
  try { if (S.ws) S.ws.close(); } catch {}
  try { if (process.stdin.isTTY) process.stdin.setRawMode(false); } catch {}
  w(A.show + A.clear);
  w(c('bgreen', '\n  👋  GamePad Pro Terminal — exited cleanly.\n\n'));
  process.exit(0);
}

// ── MAIN ──────────────────────────────────────────────────────────────
async function main() {
  w(A.hide);

  log('sys', `Terminal started — target: ${BASE}`);
  log('sys', `Node ${process.version} | PID ${process.pid}`);

  setupInput();
  connectWS();

  // Initial render
  render();

  // Poll server status every 2s
  setInterval(async () => {
    S.status = await httpGet('/status');
    if (S.tab === 'dashboard' || S.tab === 'setup') render();
  }, 2000);

  // Refresh logs every 800ms
  setInterval(() => {
    if (S.tab === 'logs') render();
  }, 800);

  // Handle terminal resize
  process.stdout.on('resize', () => {
    S.width  = process.stdout.columns || 80;
    S.height = process.stdout.rows    || 24;
    render();
  });
}

main().catch(e => {
  w(A.show);
  console.error('Fatal error:', e.message);
  process.exit(1);
});
